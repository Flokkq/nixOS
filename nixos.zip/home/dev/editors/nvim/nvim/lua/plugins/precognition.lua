return {
    {
        "tris203/precognition.nvim",
        config = {
            event = "VeryLazy",
        },
        enabled = false,
    },
}
