return {
    {
      "flokkq/calc.nvim",
      version = "v0.3.0",
    }
}
