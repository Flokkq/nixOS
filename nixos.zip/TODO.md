## stable

Things needed to be accomplished before nixos config is stable.

### common
- [ ] **0 OPEN ISSUES**
- [ ] theme switcher
- [ ] overlays/package overrides
- [ ] sops-nix

### linux

- [ ] wayland

- [ ] xorg
 - [ ] peripherals
 - [ ] graphic drivers
 - [ ] common application config
 - [ ] replicate darwin look and feel
 - [ ] simple polybar

- [ ] qemu
- [ ] schizofox
 - [ ] persistent config
 - [ ] port chrome extensions
 - [ ] textfox

- [ ] lanzaboot

### darwin

- [ ] stable de
  - [ ] auto launch
    - [ ] yabai
    - [ ] skhd
    - [ ] sketchybar
    - [ ] borders
  - [ ] yabai load scripting additions
- [ ] persistent MacOS settings
  - [ ] dock
  - [ ] native bar
  - [ ] regional settings
  - [ ] disable bloat
- [ ] spicetify-nix
- [ ] desktoppr
- [ ] impermanence?
