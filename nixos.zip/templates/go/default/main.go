package main

import (
	"fmt"
)

func main() {
	fmt.Printf("Hello from Flokkq's default-go template!")
}
