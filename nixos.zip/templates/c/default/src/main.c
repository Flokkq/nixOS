#include <stdio.h>

int main() {
    printf("Hello from Flokkq's default-c template!"); 
}
